/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package UTS_225314028;

public class TreeMain {

    public static void main(String[] args) {
       Tree V = new Tree();
       
       V.insert(23);
       V.insert(19);
       V.insert(45);
       V.insert(5);
       V.insert(21);
       V.insert(35);
       V.insert(65);
       V.insert(8);
       V.insert(33);
       V.insert(42);
       
       
        System.out.println(V.sesuatu(37));


    }
}
